package com.johanes.mgisadmin.menu;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.johanes.mgisadmin.R;

public class Maps extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
    }
}
