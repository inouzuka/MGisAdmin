package com.johanes.mgisadmin.menu;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.johanes.mgisadmin.helper.DatabaseHelper;
import com.johanes.mgisadmin.utils.Gereja;

import com.johanes.mgisadmin.R;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

class GerejaAdapter extends BaseAdapter {
    private Context mContext;
    private LayoutInflater mInflater;
    private ArrayList<Gereja> mDataSource;

    public GerejaAdapter(Context context, ArrayList<Gereja> items) {
        mContext = context;
        mDataSource = items;
        mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    //1
    @Override
    public int getCount() {
        return mDataSource.size();
    }

    //2
    @Override
    public Object getItem(int position) {
        return mDataSource.get(position);
    }

    //3
    @Override
    public long getItemId(int position) {
        return position;
    }

    //4
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get view for row item
        View rowView = mInflater.inflate(R.layout.act_list_items, parent, false);

        TextView namaGereja = (TextView) rowView.findViewById(R.id.textViewNamaGereja);
        TextView jarakGereja = (TextView) rowView.findViewById(R.id.textViewJarak);
        TextView alamatGereja = (TextView) rowView.findViewById(R.id.textViewAlamatGereja);
        ImageView gambarGereja = (ImageView) rowView.findViewById(R.id.uploadedImage);

        Gereja g = (Gereja) getItem(position);

        namaGereja.setText(g.getName());
        jarakGereja.setText("0 km");
        alamatGereja.setText(g.getAlamat());

        byte[] imgData = g.getImage();
        Bitmap bi = BitmapFactory.decodeByteArray(imgData,0,imgData.length);
        gambarGereja.setImageBitmap(bi);

        return rowView;
    }
}

public class ListGereja extends AppCompatActivity {
    private DatabaseHelper db;

    private ListView gerejaListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_list_gereja);

        gerejaListView = (ListView) findViewById (R.id.listview_gereja);

        db = new DatabaseHelper(this);

        List<Gereja> ls = db.getAllGereja();

        //String[] listItems = new String[ls.size()];
        /*for(int i = 0; i < ls.size(); i++){
            Gereja x = ls.get(i);
            try {
                Log.d("LOGG >> ", x.getName() + "|" + x.getAlamat() + "|" + x.getDeskripsi() + "|" + x.getLongi() + "|" + x.getLati() + "|" + x.getImage().length);
            } catch (Exception e){

            }

            //listItems[i] = x.getName();
        }*/

        //ArrayAdapter adp = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listItems);
        GerejaAdapter ga = new GerejaAdapter(this, new ArrayList<Gereja>(ls));
        gerejaListView.setAdapter(ga);
        gerejaListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Gereja g = (Gereja)parent.getAdapter().getItem(position);
                Intent in = new Intent(getApplicationContext(), DetailGereja.class);
                in.putExtra("id", g.getId());
                in.putExtra("nama",g.getName());
                in.putExtra("alamat", g.getAlamat());
                in.putExtra("deskripsi", g.getDeskripsi());
                in.putExtra("long", g.getLongi());
                in.putExtra("lat", g.getLati());
                in.putExtra("img", g.getImage());
                startActivity(in);
            }
        });
    }
}
